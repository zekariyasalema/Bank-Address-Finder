package com.zack.ok.bankfinder;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Name extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);
    }
}
